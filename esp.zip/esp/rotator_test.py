import socket
import time

ESP32_IP = "192.168.4.1"
ESP32_PORT = 80

def send_command(command):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5) 
            s.connect((ESP32_IP, ESP32_PORT))
            s.sendall((command + "\n").encode())
            response = s.recv(1024).decode()
            print("Response:", response)
    except Exception as e:
        print("Connection failed:", e)

print("Sending test commands...\n")

send_command("MOTOR1:3:1500")

time.sleep(3)

send_command("MOTOR2:90:1500:CW")

time.sleep(3)

send_command("MOTOR2:90:1500:CCW")

